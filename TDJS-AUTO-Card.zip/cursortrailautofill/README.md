# TDJS-AUTO Card

TDJS-AUTO Card is a redesigned browser extension that stages Stripe checkout tests in seconds. It generates cards on demand, stores your preferred BIN pattern, and auto-fills billing forms with fresh randomized data so you can focus on validating flows rather than retyping.

## What's new in the TDJS-AUTO refresh?

- Modern control center with modular sections, live status feedback, and a clear UX for QA engineers.
- Persistent BIN memory so your go-to pattern is waiting every time you relaunch.
- Guided background orchestration that opens the card generator, retrieves results, and dismisses the tab automatically.
- Adaptive identities pulled from a curated dataset to keep each submission unique.

## Getting started

1. Clone or download this repository.
2. In Chrome (or any Chromium-based browser), open `chrome://extensions/`.
3. Toggle on Developer mode in the top-right corner.
4. Click Load unpacked and select the project directory.
5. TDJS-AUTO Card is ready for launch.

## Usage flow

1. Navigate to an active Stripe Checkout page (`https://checkout.stripe.com/...`).
2. Open the TDJS-AUTO Card popup from the extensions tray.
3. Confirm or update the BIN pattern. A default of `625967xxxxxxxxxx` is included.
4. Hit Generate & Autofill.
5. Let TDJS-AUTO Card:
   - Spin up the background generator.
   - Harvest fresh cards and a randomized billing profile.
   - Populate the checkout form and notify you when it is done.

## Customization tips

- Edit the BIN pattern before triggering a run to target different card ranges.
- Clear the stored BIN via the inline control if you need a blank slate.
- Adjust styling and messaging in `popup.html` and `styles.css` to fit your team's brand, if desired.

## Stay connected

- Telegram: [@KuknibuRat](https://t.me/KuknibuRat)

## Notes and limitations

- Designed specifically for Stripe Checkout surfaces.
- Card data is generated via `https://akr-gen.bigfk.com/` and may vary based on source availability.
- Billing addresses are randomized with a Zimbabwe-focused dataset by default.

## Disclaimer

This project is provided for educational and QA automation purposes only. You are responsible for any environment where you deploy it.
