let isProcessing = false;

function waitForElement(selector, timeout = 10000) {
  return new Promise((resolve, reject) => {
    const startTime = Date.now();
    
    const checkElement = () => {
      const element = document.querySelector(selector);
      if (element) {
        resolve(element);
      } else if (Date.now() - startTime > timeout) {
        reject(new Error(`Timeout waiting for ${selector}`));
      } else {
        setTimeout(checkElement, 100);
      }
    };
    
    checkElement();
  });
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function fillCardForm() {
  if (isProcessing) {
    return;
  }
  
  isProcessing = true;
  
  try {
    const storage = await chrome.storage.local.get(['generatedCards', 'randomData']);
    
    if (!storage.generatedCards || storage.generatedCards.length === 0) {
      showNotification('⚠️ Please generate cards first from extension popup', 'warning');
      isProcessing = false;
      return;
    }
    
    const card = storage.generatedCards[Math.floor(Math.random() * storage.generatedCards.length)];
    const randomData = storage.randomData || {
      name: 'John Doe',
      address: '123 Main Street',
      address2: '',
      city: 'Harare'
    };
    
    showNotification('🔄 Auto-filling card details...', 'info');
    
    await sleep(1000);
    
    const cardButton = document.querySelector('[data-testid="card-accordion-item-button"]');
    if (cardButton) {
      cardButton.click();
      await sleep(1000);
    }
    
    const cardNumberInput = await waitForElement('input[placeholder*="1234"]');
    if (cardNumberInput) {
      cardNumberInput.focus();
      cardNumberInput.value = card.card_number;
      cardNumberInput.dispatchEvent(new Event('input', { bubbles: true }));
      cardNumberInput.dispatchEvent(new Event('change', { bubbles: true }));
      await sleep(300);
    }
    
    const expiryInput = document.querySelector('input[placeholder*="MM"]');
    if (expiryInput) {
      const expiryStr = `${card.expiry_month}${card.expiry_year.slice(-2)}`;
      expiryInput.focus();
      expiryInput.value = expiryStr;
      expiryInput.dispatchEvent(new Event('input', { bubbles: true }));
      expiryInput.dispatchEvent(new Event('change', { bubbles: true }));
      await sleep(300);
    }
    
    const cvcInputs = document.querySelectorAll('input[placeholder="CVC"], input[name*="cvc"], input[name*="cvv"]');
    if (cvcInputs.length > 0) {
      const cvcInput = cvcInputs[0];
      cvcInput.focus();
      cvcInput.value = card.cvv;
      cvcInput.dispatchEvent(new Event('input', { bubbles: true }));
      cvcInput.dispatchEvent(new Event('change', { bubbles: true }));
      await sleep(300);
    }
    
    const nameInput = document.querySelector('input[placeholder*="Full name"], input[placeholder*="name on card"]');
    if (nameInput) {
      nameInput.focus();
      nameInput.value = randomData.name;
      nameInput.dispatchEvent(new Event('input', { bubbles: true }));
      nameInput.dispatchEvent(new Event('change', { bubbles: true }));
      await sleep(300);
    }
    
    const countrySelect = document.querySelector('select');
    if (countrySelect) {
      countrySelect.value = 'ZW';
      countrySelect.dispatchEvent(new Event('change', { bubbles: true }));
      await sleep(500);
    }
    
    await sleep(500);
    
    const addressInputs = document.querySelectorAll('input[type="text"]');
    for (const input of addressInputs) {
      const placeholder = input.getAttribute('placeholder') || '';
      const name = input.getAttribute('name') || '';
      
      if (placeholder.toLowerCase().includes('address') && !placeholder.toLowerCase().includes('line 2')) {
        input.focus();
        input.value = randomData.address;
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
        await sleep(300);
      } else if (placeholder.toLowerCase().includes('line 2') && randomData.address2) {
        input.focus();
        input.value = randomData.address2;
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
        await sleep(300);
      } else if (placeholder.toLowerCase().includes('city')) {
        input.focus();
        input.value = randomData.city;
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
        await sleep(300);
      }
    }
    
    showNotification('✅ All details filled successfully!', 'success');
    
  } catch (error) {
    showNotification('❌ Error: ' + error.message, 'error');
  }
  
  isProcessing = false;
}

function showNotification(message, type = 'info') {
  const existing = document.getElementById('auto-card-filler-notification');
  if (existing) existing.remove();
  
  const notification = document.createElement('div');
  notification.id = 'auto-card-filler-notification';
  notification.textContent = message;
  
  const colors = {
    info: '#3498db',
    success: '#2ecc71',
    warning: '#f39c12',
    error: '#e74c3c'
  };
  
  Object.assign(notification.style, {
    position: 'fixed',
    top: '20px',
    right: '20px',
    background: colors[type] || colors.info,
    color: 'white',
    padding: '15px 20px',
    borderRadius: '8px',
    boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
    zIndex: '999999',
    fontSize: '14px',
    fontWeight: '600',
    maxWidth: '300px',
    animation: 'slideIn 0.3s ease-out'
  });
  
  const style = document.createElement('style');
  style.textContent = `
    @keyframes slideIn {
      from { transform: translateX(400px); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
  `;
  document.head.appendChild(style);
  
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.style.transition = 'all 0.3s ease-out';
    notification.style.transform = 'translateX(400px)';
    notification.style.opacity = '0';
    setTimeout(() => notification.remove(), 300);
  }, 5000);
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'fillForm') {
    fillCardForm();
  }
});

