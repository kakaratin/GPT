#pragma once
bool ConfigUnlockSkin = false;
bool ConfigProtection = false;


bool IsMinimap = false;

bool (*oMinimap)(void *thiz);
bool _Minimap(void *thiz) {
    if (thiz != NULL && IsMinimap) {
          return true;
    }
    return oMinimap(thiz);
}
/////////////////remove if error///////////
bool IsEnemyBot = false;

bool (*oEnemyBot)(void *thiz);
bool _EnemyBot(void *thiz) {
    if (thiz != NULL && IsEnemyBot) {
          return true;
    }
    return oEnemyBot(thiz);
}


bool IsEnemyEasy = false;

bool (*oEnemyEasy)(void *thiz);
bool _EnemyEasy(void *thiz) {
    if (thiz != NULL && IsEnemyEasy) {
          return true;
    }
    return oEnemyEasy(thiz);
}

/////////////////remove uf error//////////
double IsAttkSpeed = 0;

double (*oAttkSpeed)(void *thiz);
double _AttkSpeed(void *thiz) {
    if (thiz != NULL && IsAttkSpeed > 0) {
          return IsAttkSpeed;
    }
    return oAttkSpeed(thiz);
}


int IsMoveUpdate = 0;

void (*oMoveUpdate)(void *thiz, int iTimeDelta);

void _MoveUpdate(void *thiz, int iTimeDelta) {
    if (thiz != NULL && IsMoveUpdate > 0) {
        // Paksa waktu update (cepat / slow motion / speedhack)
        oMoveUpdate(thiz, IsMoveUpdate);
        return;
    }

    // Default bawaan game
    oMoveUpdate(thiz, iTimeDelta);
}


bool IsNoCd = false;

int (*oCalcSkillCoolDown)(void *thiz, int iCoolDownTime, int iSpellId);
int _CalcSkillCoolDown(void *thiz, int iCoolDownTime, int iSpellId) {

    if (thiz != NULL && IsNoCd) {
        return 0;  // cooldown jadi 0
    }

    return oCalcSkillCoolDown(thiz, iCoolDownTime, iSpellId);
}

bool HighDamage = false;

int (*oGetOnceHurtAdd)(void *thiz);

int _GetOnceHurtAdd(void *thiz) {
    int result = oGetOnceHurtAdd(thiz);

    if (HighDamage) {
      
        result += 99999;
    }

    return result;
}


// pointer ke field
uintptr_t field_m_bAntiCheatReport = 0;

// ubah field menjadi false (nonaktif)
void DisableAntiCheatReport() {
    if (field_m_bAntiCheatReport != 0) {
        bool *value = (bool*)field_m_bAntiCheatReport;
        *value = true;
    }
}

bool IsInitPlugInTesting = true;

void (*oInitPlugInTesting)(void *thiz);
void _InitPlugInTesting(void *thiz) {
    if (thiz != NULL && IsInitPlugInTesting) {
        return;
    }

    oInitPlugInTesting(thiz);
}


bool IsCheckMobaPluginExists = true;

bool (*oCheckMobaPluginExists)();
bool _CheckMobaPluginExists() {
    if (IsCheckMobaPluginExists) {
        // hasil palsu
        return false;   // bilang "plugin tidak ada"
    }

    return oCheckMobaPluginExists();
}

bool IsReportDamageValidationData = true;

void (*oReportDamageValidationData)(void* thiz);
void _ReportDamageValidationData(void* thiz) {
    if (thiz != NULL && IsReportDamageValidationData) {
        // Bypass laporan damage → jangan kirim apa pun
        return;
    }

    oReportDamageValidationData(thiz);
}


bool IsReportDamageError = true;

void (*oReportDamageError)(void* thiz);
void _ReportDamageError(void* thiz) {
    if (thiz != NULL && IsReportDamageError) {
        // Bypass anti-cheat damage error report
        return; 
    }

    oReportDamageError(thiz);
}


bool g_DisableAntiCheat = true;       // jika true -> bypass aktif
bool g_AllowReportSkillInfo = false;   // kalau mau sementara izinkan report, set true

// --- original function pointers ---
void (*oStartBattle)(void *instance);
void (*oEndBattle)(void *instance);
void (*oOnReleaseUseSkill)(void *instance, int skillID);
void (*oOnTryUseSkill_2)(void *instance, int skillID, void *vec3_dir);             // overload with (Int32, Vector3)
void (*oOnTryUseSkill_3)(void *instance, int initSkillID, int skillID, void *vec3); // overload with (Int32, Int32, Vector3)
void (*oOnRequestSkillMsg)(void *instance, int skillId, void *vec3_dir);
bool (*oHasSkillInfo)(void *instance);
void (*oReportSkillInfo)(void *instance, void *stringBuilder);

// --- hooked implementations (no-op / safe) ---

// StartBattle
void _StartBattle(void *instance) {
    if (!g_DisableAntiCheat) {
        // jika bypass non-aktif, panggil original
        return oStartBattle(instance);
    }
    // bypass: jangan lakukan apa-apa (no-op)
    return;
}

// EndBattle
void _EndBattle(void *instance) {
    if (!g_DisableAntiCheat) {
        return oEndBattle(instance);
    }
    return;
}

// OnReleaseUseSkill(Int32 skillID)
void _OnReleaseUseSkill(void *instance, int skillID) {
    if (!g_DisableAntiCheat) {
        return oOnReleaseUseSkill(instance, skillID);
    }
    // no-op
    return;
}

// OnTryUseSkill(Int32 skillID, Vector3 dir)
void _OnTryUseSkill_2(void *instance, int skillID, void *vec3_dir) {
    if (!g_DisableAntiCheat) {
        return oOnTryUseSkill_2(instance, skillID, vec3_dir);
    }
    return;
}

// OnTryUseSkill(Int32 initSkillID, Int32 skillID, Vector3 dir)
void _OnTryUseSkill_3(void *instance, int initSkillID, int skillID, void *vec3_dir) {
    if (!g_DisableAntiCheat) {
        return oOnTryUseSkill_3(instance, initSkillID, skillID, vec3_dir);
    }
    return;
}

// OnRequestSkillMsg(Int32 skillId, Vector3 dir)
void _OnRequestSkillMsg(void *instance, int skillId, void *vec3_dir) {
    if (!g_DisableAntiCheat) {
        return oOnRequestSkillMsg(instance, skillId, vec3_dir);
    }
    return;
}

// HasSkillInfo() -> kita paksa false agar system mengira tidak ada info untuk dilaporkan
bool _HasSkillInfo(void *instance) {
    if (!g_DisableAntiCheat) {
        return oHasSkillInfo(instance);
    }
    return false;
}

// ReportSkillInfo(StringBuilder strContent) -> no-op (jangan isi string)
void _ReportSkillInfo(void *instance, void *stringBuilder) {
    if (!g_DisableAntiCheat || g_AllowReportSkillInfo) {
        return oReportSkillInfo(instance, stringBuilder);
    }
    // bypass: kosongkan / abaikan laporan
    return;
}


void InstallAntiCheatBypass() {

    Tools::Hook((void *) Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("AntiCheatReporter"), OBFUSCATE("StartBattle"), 0),
                (void *) _StartBattle, (void **) &oStartBattle);

    Tools::Hook((void *) Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("AntiCheatReporter"), OBFUSCATE("EndBattle"), 0),
                (void *) _EndBattle, (void **) &oEndBattle);

    Tools::Hook((void *) Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("AntiCheatReporter"), OBFUSCATE("OnReleaseUseSkill"), 1),
                (void *) _OnReleaseUseSkill, (void **) &oOnReleaseUseSkill);

    // overload OnTryUseSkill (2 params)
    Tools::Hook((void *) Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("AntiCheatReporter"), OBFUSCATE("OnTryUseSkill"), 2),
                (void *) _OnTryUseSkill_2, (void **) &oOnTryUseSkill_2);

    // overload OnTryUseSkill (3 params)
    Tools::Hook((void *) Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("AntiCheatReporter"), OBFUSCATE("OnTryUseSkill"), 3),
                (void *) _OnTryUseSkill_3, (void **) &oOnTryUseSkill_3);

    Tools::Hook((void *) Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("AntiCheatReporter"), OBFUSCATE("OnRequestSkillMsg"), 2),
                (void *) _OnRequestSkillMsg, (void **) &oOnRequestSkillMsg);

    Tools::Hook((void *) Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("AntiCheatReporter"), OBFUSCATE("HasSkillInfo"), 0),
                (void *) _HasSkillInfo, (void **) &oHasSkillInfo);

    Tools::Hook((void *) Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("AntiCheatReporter"), OBFUSCATE("ReportSkillInfo"), 1),
                (void *) _ReportSkillInfo, (void **) &oReportSkillInfo);

    // Done
}


//Class Camera
#define Camera_get_main (uintptr_t) Il2CppGetMethodOffset("UnityEngine.dll", "UnityEngine", "Camera", "get_main")
#define Camera_WorldToScreenPoint (uintptr_t) Il2CppGetMethodOffset("UnityEngine.dll", "UnityEngine", "Camera", "WorldToScreenPoint", 1)
#define Camera_get_fieldOfView (uintptr_t) Il2CppGetMethodOffset("UnityEngine.dll", "UnityEngine", "Camera", "get_fieldOfView")
#define Camera_set_fieldOfView (uintptr_t) Il2CppGetMethodOffset("UnityEngine.dll", "UnityEngine", "Camera", "set_fieldOfView", 1)

void *get_main() {
	return reinterpret_cast<void *(__fastcall *)()>(Camera_get_main)();
}

Vector3 WorldToScreen(Vector3 position) {
	return reinterpret_cast<Vector3(__fastcall *)(void *, Vector3)>(Camera_WorldToScreenPoint)(get_main(), position);
}

float get_fieldOfView() {
	return reinterpret_cast<float(__fastcall *)(void *)>(Camera_get_fieldOfView)(get_main());
}

void *set_fieldOfView(float value) {
	return reinterpret_cast<void *(__fastcall *)(void *, float)>(Camera_set_fieldOfView)(get_main(), value);
}


//Class BattleBridge
#define BattleBridge_bStartBattle (uintptr_t) Il2CppGetFieldOffset("Assembly-CSharp.dll", "", "BattleBridge", "bStartBattle")

//Class CmdHeroSkin
#define CmdHeroSkin__ctor (uintptr_t) (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "MTTDProto", "CmdHeroSkin", ".ctor")

//Class CmdHeroStatue
#define CmdHeroStatue__ctor (uintptr_t) (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "MTTDProto", "CmdHeroStatue", ".ctor")

//Class SystemData
#define SystemData_GetHeroSkin (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "SystemData", "GetHeroSkin", 2)
#define SystemData_GetMCLimitSkin (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "SystemData", "GetMCLimitSkin", 1)
#define SystemData_GetHeroHolyStatue (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "SystemData", "GetHeroHolyStatue", 2)
#define SystemData_IsCanUseSkin (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "SystemData", "IsCanUseSkin", 1)
#define SystemData_IsHaveSkin (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "SystemData", "IsHaveSkin", 1)
#define SystemData_IsHaveSkinForever (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "SystemData", "IsHaveSkinForever", 1)
#define SystemData_IsHaveStatue (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "SystemData", "IsHaveStatue", 1)
#define SystemData_IsHaveStatueForever (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "SystemData", "IsHaveStatueForever", 1)
#define SystemData_IsForbidStatue (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "SystemData", "IsForbidStatue", 1)
#define SystemData_IsForbidSkin (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "SystemData", "IsForbidSkin", 1)
#define SystemData_IsForbidARSkin (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "SystemData", "IsForbidARSkin", 1)
#define SystemData_IsForbidARHero (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "SystemData", "IsForbidARHero", 1)
#define SystemData_IsForbidHeros (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "SystemData", "IsForbidHeros", 1)
#define SystemData_IsForbidNewHeroList (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "SystemData", "IsForbidNewHeroList", 1)
#define SystemData_RoomData_iPos (uintptr_t) Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("SystemData/RoomData"), OBFUSCATE("iPos"))


//Class UIChooseHero
#define UIChooseHero_ShowSkinExpiryDate (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "UIChooseHero", "ShowSkinExpiryDate",0 )   //CheckHeroDefaultSkin
#define UIChooseHero_SendSelectSkin (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "ChooseHeroMgr", "SendSelectSkin", 2)
#define UIChooseHero_SendSelectSkin2 (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "UIChooseHero", "CheckHeroDefaultSkin", 2)

//Class UIRankHero
#define UIRankHero_BatttleSelectSkin (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "UIRankHero", "BatttleSelectSkin", 2)
#define UIRankHero_BatttleSelectSkin2 (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "UIChooseHero", "BatttleSelectSkin", 2)

//Class UIRankHero.ChangeShow
#define UIRankHero_ChangeShow_SendUseSkin (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "UIRankHero/ChangeShow", "SendUseSkin", 2)

//Class BattleReceiveMessage
#define BattleReceiveMessage_SetPlayerData (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "BattleReceiveMessage", "SetPlayerData", 2)
#define BattleReceiveMessage_SetPlayerData_ (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "BattleReceiveMessage", "SetPlayerData", 1)
#define BattleReceiveMessage_AddPlayerInfo (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "BattleReceiveMessage", "AddPlayerInfo", 4)
#define BattleReceiveMessage_AddPlayerInfo_ (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "BattleReceiveMessage", "AddPlayerInfo", 2)

//Class BattlePlayerInfo
#define BattlePlayerInfo_lUid (uintptr_t) Il2CppGetFieldOffset("Assembly-CSharp.dll", "MTTDProto", "BattlePlayerInfo", "lUid")
#define BattlePlayerInfo_uiSelHero (uintptr_t) Il2CppGetFieldOffset("Assembly-CSharp.dll", "MTTDProto", "BattlePlayerInfo", "uiSelHero")
#define BattlePlayerInfo_uiSkinId (uintptr_t) Il2CppGetFieldOffset("Assembly-CSharp.dll", "MTTDProto", "BattlePlayerInfo", "uiSkinId")

//Unlock Skin -> Mencoba
//Class UIRankHero.ChangeShow
#define UIRankHero_ChangeShow_iSelfHero (uintptr_t) Il2CppGetFieldOffset("Assembly-CSharp.dll", "", "UIRankHero/ChangeShow", "iSelfHero")
//Class GameServerConfig
#define GameServerConfig_SendRawData (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "GameServerConfig", "SendRawData", 8)

static float SetFieldOfView = 0, GetFieldOfView = 0;

void DroneView() {
    if (GetFieldOfView == 0) {
        GetFieldOfView = get_fieldOfView();
    }
    if (SetFieldOfView > 0 && GetFieldOfView != 0) {
        set_fieldOfView((float)GetFieldOfView + SetFieldOfView);
    }
    if (SetFieldOfView == 0 && GetFieldOfView != 0) {
        set_fieldOfView((float)GetFieldOfView);
    }
}

void DrawESP(ImDrawList *draw, int screenWidth, int screenHeight) {

    void *BattleBridge_Instance;
    Il2CppGetStaticFieldValue("Assembly-CSharp.dll", "", "BattleData", "m_BattleBridge", &BattleBridge_Instance);

    if (BattleBridge_Instance) {

        auto _bStartBattle = *(bool *) ((uintptr_t)BattleBridge_Instance + BattleBridge_bStartBattle);

        if (_bStartBattle) {
            // 🟢 **Only Drone View**
            DroneView();
        }
    }
}
