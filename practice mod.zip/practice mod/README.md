How to Inject 


----------- [ Without Overlay Permission ] -----------

[*] Add lib 
[*] Add class
[*] Add invoke code (MainActivity)

invoke-static {p0}, Lcom/android/support/Main;->StartWithoutPermission(Landroid/content/Context;)V


----------- [ With Overlay Permission ] -----------

[✓] Add This In Android Manifest.xml

- Add Under Internet or other permissions 

<uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW"/>

[✓] Add this before </application> tag ( at the end of file )

    <service
      android:name="com.android.support.Launcher"
       android:enabled="true"
       android:exported="true"
       android:stopWithTask="true"/>

[✓] Add Under On create
invoke-static {p0}, Lcom/android/support/Main;->Start(Landroid/content/Context;)V

--------------------------------------------------------