#include <list>
#include <vector>
#include <cstring>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <string>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <EGL/egl.h>
#include "dobby/dobby.h"
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "imgui/imgui.h"
#include "imgui/imgui_additional.h"
#include "imgui/backends/imgui_impl_android.h"
#include "imgui/backends/imgui_impl_opengl3.h"
#include "imgui/android_native_app_glue.h"
#include "Includes/Utils.hpp"
#include "Struct/Vector3.h"
#include "Struct/Vector2.h"
#include "Struct/Color.h"
#include "Struct/Rect.h"
#include "Struct/Quaternion.h"
#include "Struct/MonoString.h"
#include "unity/fake_dlfcn.h"
#include "unity/Il2Cpp.h"
#include "unity/Tools.h"
#include "unity/Unity.h"
#include "Menu/Menu.hpp"
#include "Menu/Jni.hpp"
#include "Includes/Macros.h"
#include "Hook.h"
#include "UnlockSkin.h"
#include "protection.h"
//#include "DrawESP.h"
//a58169.dns.nextdns.io

#define m_IL2CPPLIB "libil2cpp.so"
uintptr_t m_IL2CPP;
int glWidth, glHeight;
bool g_Initialized;
void *m_EGL;

EGLBoolean (*orig_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
EGLBoolean _eglSwapBuffers (EGLDisplay dpy, EGLSurface surface) {
	
	eglQuerySurface(dpy, surface, EGL_WIDTH, &glWidth);
	eglQuerySurface(dpy, surface, EGL_HEIGHT, &glHeight);
	
	if (glWidth <= 0 || glHeight <= 0) {
		return eglSwapBuffers(dpy, surface);
	}
	
	if (!g_Initialized) {
		ImGui::CreateContext();
		ImGuiStyle* style = &ImGui::GetStyle();
		ImGui::StyleColorsDark();
		ImGuiIO* io = &ImGui::GetIO();
		io->IniFilename = nullptr;
		ImGui_ImplAndroid_Init();
		ImGui_ImplOpenGL3_Init("#version 300 es");
		ImFontConfig font_cfg;
		font_cfg.SizePixels = 22.0f;
		g_Initialized = true;
    }
	
	ImGuiIO* io = &ImGui::GetIO();
	ImGui_ImplOpenGL3_NewFrame();
	ImGui_ImplAndroid_NewFrame(glWidth, glHeight);
	ImGui::NewFrame();
	
	UnlockSkin();
	
	DrawESP(ImGui::GetBackgroundDrawList(), glWidth, glHeight);

	ImGui::Render();
	ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
	return orig_eglSwapBuffers(dpy, surface);
}

jobjectArray GetFeatureList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
		    OBFUSCATE("Category_𝑹𝑨𝑵𝑲𝑩𝑶𝑶𝑺𝑻𝑬𝑹 (𝑽𝑰𝑷)"), //Not counted
            OBFUSCATE("9_Toggle_𝑬𝒏𝒆𝒎𝒚 𝑩𝒐𝒕"),
			OBFUSCATE("10_Toggle_𝑬𝒏𝒆𝒎𝒚 𝑬𝒂𝒔𝒚"),
		
		    OBFUSCATE("Category_𝑩𝒀𝑷𝑨𝑺𝑺 𝑫𝑵𝑺"), //Not counted
		    OBFUSCATE("8_Toggle_𝑩𝒚𝒑𝒂𝒔𝒔"),
			
		    OBFUSCATE("Category_𝑴𝑨𝑷 𝑯𝑨𝑪𝑲"), //Not counted
            OBFUSCATE("1_Toggle_𝑴𝒂𝒑𝑯𝒂𝒄𝒌-𝑭𝒖𝒍𝒍𝒔𝒊𝒈𝒉𝒕"),
			
			OBFUSCATE("Category_𝑪𝑨𝑴𝑬𝑹𝑨"), //Not counted
            OBFUSCATE("2_SeekBar_𝑫𝒓𝒐𝒏𝒆 𝑽𝒊𝒆𝒘_0_50"),
			
			OBFUSCATE("Category_𝑩𝑹𝑼𝑻𝑨𝑳 𝑯𝑨𝑪𝑲"), //Not counted
			OBFUSCATE("4_SeekBar_𝑹𝒖𝒏 𝑺𝒑𝒆𝒆𝒅_0_200"),
			OBFUSCATE("5_SeekBar_𝑨𝒕𝒕𝒌 𝑺𝒑𝒆𝒆𝒅_0_100"),
			OBFUSCATE("6_Toggle_𝑵𝒐 𝑪𝒅 𝑺𝒌𝒊𝒍𝒍"),
			OBFUSCATE("7_Toggle_𝑶𝒏𝒆 𝑯𝒊𝒕"),
			
			OBFUSCATE("ButtonLink_𝑱𝒐𝒊𝒏 𝑴𝒚 𝑻𝒆𝒍𝒆𝒈𝒓𝒂𝒎 𝑪𝒉𝒂𝒏𝒏𝒆𝒍_https://t.me/+E3T8HySkGGQ3N2M1"), //link
    };

    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

void Changes(JNIEnv *env, jclass clazz, jobject obj, jint featNum, jstring featName, jint value, jlong Lvalue, jboolean boolean, jstring text) {

    switch (featNum) {
		case 1:
        IsMinimap = boolean;
        break;
		
		case 2:
        SetFieldOfView = value;
        break;
		
		/*case 3:
		ConfigUnlockSkin = boolean;
		break;*/
		
		case 5:
        IsAttkSpeed = value;
        break;
		
		case 4:
        IsMoveUpdate = value;
        break;
		
		case 6:
		IsNoCd = boolean;
		break;
		
		case 7:
		HighDamage = boolean;
		break;
		
		case 8:
		ConfigProtection = boolean;
		break;
		
		case 9:
		IsEnemyBot = boolean;
		break;
		
		case 10:
		IsEnemyEasy = boolean;
		break;

		
    }
}

void *hack_thread(void *) {
    while (!m_IL2CPP) {
        m_IL2CPP = Tools::GetBaseAddress(m_IL2CPPLIB);
        sleep(1);
    }

    while (!m_EGL) {
        m_EGL = dlopen("libEGL.so", RTLD_NOW);
        sleep(1);
    }

    Il2CppAttach(m_IL2CPPLIB);
    sleep(5);
	DobbyHook((void *) dlsym(m_EGL, OBFUSCATE("eglSwapBuffers")), (void *) _eglSwapBuffers, (void **) &orig_eglSwapBuffers);
	
	Tools::Hook((void *) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "ShowEntity", "get_m_CanSight", 0), (void *) _Minimap, (void **) &oMinimap);
	Tools::Hook((void *) Il2CppGetMethodOffset("Assembly-CSharp.dll", "Battle", "LogicPlayer", "get_m_AttkSpeed", 0), (void *) _AttkSpeed, (void **) &oAttkSpeed);
	Tools::Hook((void *) Il2CppGetMethodOffset("Assembly-CSharp.dll", "Battle", "LogicPlayer", "MoveUpdate", 1), (void *) _MoveUpdate, (void **) &oMoveUpdate);
	Tools::Hook((void *) Il2CppGetMethodOffset("Assembly-CSharp.dll", "Battle", "LogicFighter", "CalcSkillCoolDown", 2), (void *) _CalcSkillCoolDown, (void **) &oCalcSkillCoolDown);
	Tools::Hook((void *) Il2CppGetMethodOffset("Assembly-CSharp.dll", "Battle", "LogicFighter", "GetOnceHurtAdd", 0), (void *) _GetOnceHurtAdd, (void **) &oGetOnceHurtAdd);
	
	
	Tools::Hook((void *) SystemData_GetHeroSkin, (void *) GetHeroSkin, (void **) &oGetHeroSkin);
    Tools::Hook((void *) SystemData_GetMCLimitSkin, (void *) GetMCLimitSkin, (void **) &oGetMCLimitSkin);
    Tools::Hook((void *) SystemData_IsCanUseSkin, (void *) IsCanUseSkin, (void **) &oIsCanUseSkin);
    Tools::Hook((void *) SystemData_IsHaveSkin, (void *) IsHaveSkin, (void **) &oIsHaveSkin);
    Tools::Hook((void *) SystemData_IsHaveSkinForever, (void *) IsHaveSkinForever, (void **) &oIsHaveSkinForever);
    Tools::Hook((void *) SystemData_IsForbidStatue, (void *) IsForbidStatue, (void **) &oIsForbidStatue);
    Tools::Hook((void *) SystemData_IsForbidSkin, (void *) IsForbidSkin, (void **) &oIsForbidSkin);
    Tools::Hook((void *) SystemData_IsForbidARSkin, (void *) IsForbidARSkin, (void **) &oIsForbidARSkin);
    Tools::Hook((void *) UIChooseHero_SendSelectSkin, (void *) SendSelectSkin, (void **) &oSendSelectSkin);
    Tools::Hook((void *) UIChooseHero_SendSelectSkin2, (void *) SendSelectSkin2, (void **) &oSendSelectSkin2);
    Tools::Hook((void *) UIChooseHero_ShowSkinExpiryDate, (void *) ShowSkinExpiryDate, (void **) &oShowSkinExpiryDate);
    Tools::Hook((void *) UIRankHero_BatttleSelectSkin, (void *) BatttleSelectSkin, (void **) &oBatttleSelectSkin);
    Tools::Hook((void *) UIRankHero_BatttleSelectSkin2, (void *) BatttleSelectSkin2, (void **) &oBatttleSelectSkin2);
    Tools::Hook((void *) UIRankHero_ChangeShow_SendUseSkin, (void *) SendUseSkin, (void **) &oSendUseSkin);
    Tools::Hook((void *) BattleReceiveMessage_SetPlayerData, (void *) SetPlayerData, (void **) &oSetPlayerData);
    Tools::Hook((void *) GameServerConfig_SendRawData, (void *) SendRawData, (void **) &oSendRawData);
	
	field_m_bAntiCheatReport = (uintptr_t) Il2CppGetFieldOffset("NamaAssembly.dll","","ShowBattleControl","m_bAntiCheatReport");
	Tools::Hook((void *) Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("GameMain"), OBFUSCATE("InitPlugInTesting"), 0), (void *) _InitPlugInTesting, (void **) &oInitPlugInTesting);
	Tools::Hook((void *) Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("GameMain"), OBFUSCATE("CheckMobaPluginExists"), 0), (void *) _CheckMobaPluginExists, (void **) &oCheckMobaPluginExists);
	Tools::Hook((void *) Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("BattleEndReport"), OBFUSCATE("ReportDamageValidationData"), 0), (void *) _ReportDamageValidationData, (void **) &oReportDamageValidationData);
	Tools::Hook((void *) Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("BattleEndReport"), OBFUSCATE("ReportDamageError"), 0), (void *) _ReportDamageError, (void **) &oReportDamageError);
	
	InstallAntiCheatBypass();
    LOGI(OBFUSCATE("Done"));
    return NULL;
}


__attribute__((constructor))
void lib_main() {
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}
